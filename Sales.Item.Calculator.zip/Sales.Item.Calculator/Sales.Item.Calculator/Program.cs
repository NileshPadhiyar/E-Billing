﻿using Sales.Item.Calculator.Services;
using System;

namespace Sales.Item.Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Sales Item Calculator";
            Console.WriteLine("\nWelcome to E-Billing...\n");

            Shopping shopping = Shopping.GetInstance();
            shopping.Start();

            DiscountHandler handler1 = new IndividualDiscountHandler();
            DiscountHandler handler2 = new WeekdayDiscountHandler();
            //DiscountHandler handler3 = new CreditCardDiscountHandler();   //Can be extended horizontally

            handler1.SetSuccessor(handler2);
            //handler2.SetSuccessor(handler3);

            handler1.CalculateDiscount();

            Console.ReadKey();
        }
    }
}
