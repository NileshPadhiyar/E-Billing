﻿using Sales.Item.Calculator.Common;
using Sales.Item.Calculator.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Sales.Item.Calculator.Services
{
    /// <summary>
    /// Shopping
    /// </summary>
    public class Shopping
    {
        static Shopping instance;
        public List<DiscountItemModel> cartItemList = new List<DiscountItemModel>();
        LoadProduct loadProductObj = new LoadProduct();
        private Shopping()
        {

        }

        public static Shopping GetInstance()
        {
            if (instance == null)
            {
                instance = new Shopping();
            }

            return instance;
        }

        /// <summary>
        /// Load Product list from file and Display it 
        /// </summary>
        public void Start()
        {
            loadProductObj.LoadProducts();

            loadProductObj.DisplayProducts();

            GetUserInput();
        }

        /// <summary>
        /// Get Input from User
        /// </summary>
        private void GetUserInput()
        {
            #region Start Adding item to class
            string wantToAddAnotherItem;
            int selectedItemNumber = 0;
            int enteredQuantity = 0;
            ItemModel selectedItem;            
            do
            {
                Console.Write(BusinessMessage.SelectProductId);
                string productNumber = Console.ReadLine();
                bool hasItem = int.TryParse(productNumber, out selectedItemNumber);

                if (hasItem)
                {
                    selectedItem = loadProductObj.productList.Find(m => m.ItemId == selectedItemNumber);
                    Console.Write(BusinessMessage.EnterQuantity, selectedItem.ItemName.Trim());
                    string quantity = Console.ReadLine();
                    int.TryParse(quantity, out enteredQuantity);

                    AddItemToCartWithCreatorType(selectedItem, enteredQuantity);

                    Console.Write(BusinessMessage.ItemAddedToCart, enteredQuantity, selectedItem.ItemName.Trim());
                }
                else
                {
                    Console.WriteLine(BusinessMessage.ProductIdNotExists, productNumber);
                }

                Console.Write(BusinessMessage.ConfirmationToAddOtherItem);
                wantToAddAnotherItem = Console.ReadLine();
            } while (wantToAddAnotherItem.ToUpper() != Constant.NO);      //Exist loop by pressing N only

            #endregion

        }

        /// <summary>
        /// Add Item To Cart With CreatorType
        /// </summary>
        /// <param name="selectedItem"></param>
        /// <param name="enteredQuantity"></param>
        public void AddItemToCartWithCreatorType(ItemModel selectedItem, int enteredQuantity)
        {
            DiscountItem _discountItem;
            DiscountItemModel existingCartItem = cartItemList.SingleOrDefault(m => m.Item == selectedItem);        //TRy .ItemId as well
            if (existingCartItem != null)
            {
                existingCartItem.Quantity = existingCartItem.Quantity + enteredQuantity;
            }
            else
            {
                if (string.IsNullOrEmpty(selectedItem.Discount.ToString()) || selectedItem.Discount.ToString().Contains(Constant.PERCENTAGE) || selectedItem.Discount.ToString().Trim() == "0")     //Switch can also be used
                {
                    _discountItem = new PercentageDiscountItemCreator(selectedItem.Discount.ToString());
                }
                else if (selectedItem.Discount.ToString().Contains(Constant.TILDE))
                {
                    _discountItem = new UnitBaseDiscountItemCreator(selectedItem.Discount.ToString());

                }
                else
                {
                    throw new Exception(BusinessMessage.InvalidDiscountDetails);
                }

                DiscountItemModel discountItem = new DiscountItemModel() { Item = selectedItem, Quantity = enteredQuantity, DiscountItemCreator = _discountItem };
                cartItemList.Add(discountItem);
            }
        }
    }
}
