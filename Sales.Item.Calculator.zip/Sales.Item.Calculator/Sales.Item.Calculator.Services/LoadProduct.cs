﻿using Newtonsoft.Json;
using Sales.Item.Calculator.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Sales.Item.Calculator.Services
{
    public class LoadProduct
    {
        private const string jsonFileName = "../../App_Data/ProductDetails.json";    //Fixed

        public List<ItemModel> productList = new List<ItemModel>();
        public void LoadProducts()
        {
            if (File.Exists(jsonFileName))
            {
                using (StreamReader reader = new StreamReader(jsonFileName))
                {
                    string json = reader.ReadToEnd();
                    List<ItemModel> dictionaryFromJson = JsonConvert.DeserializeObject<List<ItemModel>>(json);
                    productList.AddRange(dictionaryFromJson.ToList());
                }
            }
            //else
            //{
            //    LoadInMemoryProducts();
            //}
        }

        //private void LoadInMemoryProducts()
        //{
        //    ProductList.Add(new ItemModel() { ItemId = 1, ItemName = "Thumbs up     ", Price = 100, Discount = "10%" });
        //    ProductList.Add(new ItemModel() { ItemId = 2, ItemName = "Toilet Cleaner", Price = 250, Discount = "10%" });
        //    ProductList.Add(new ItemModel() { ItemId = 3, ItemName = "Mangoes       ", Price = 120, Discount = "0%" });
        //    ProductList.Add(new ItemModel() { ItemId = 4, ItemName = "Cooking Oil   ", Price = 150, Discount = "3~1" });
        //    ProductList.Add(new ItemModel() { ItemId = 5, ItemName = "Sugar         ", Price = 40, Discount = "0%" });
        //    ProductList.Add(new ItemModel() { ItemId = 6, ItemName = "Tea           ", Price = 125, Discount = "0%" });
        //    ProductList.Add(new ItemModel() { ItemId = 7, ItemName = "Bulbs         ", Price = 70, Discount = "0%" });
        //    ProductList.Add(new ItemModel() { ItemId = 8, ItemName = "Envelop       ", Price = 2, Discount = "2~1" });
        //}

        public void DisplayProducts()
        {
            Console.WriteLine("Available Products");
            Console.WriteLine("-----------------------");
            foreach (var item in productList.ToList().OrderBy(m => m.ItemId))
            {
                Console.WriteLine("Id: {0}, Name: {1}, Price: {2} | *Discount: {3}", item.ItemId, item.ItemName, item.Price, item.Discount);        // (item.GetType().ToString().Contains("PercentageDiscount") ? ((PercentageDiscount)item).GetDiscountDetails(): ((UnitBaseDiscount)item).GetDiscountDetails())
            }
            Console.WriteLine("-----------------------\n");
        }
    }
}
