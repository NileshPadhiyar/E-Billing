﻿using Newtonsoft.Json;
using Sales.Item.Calculator.Common;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;

namespace Sales.Item.Calculator.Services
{
    public class WeekdayDiscountHandler : DiscountHandler
    {
        private static Dictionary<DayOfWeek, int> dayDiscountKeyValuePairs = new Dictionary<DayOfWeek, int>();
        private static string jsonFileName = "../../App_Data/DaywiseDiscount.json";
        public WeekdayDiscountHandler()
        {
            ReadInputJsonFile();
        }

        private static void ReadInputJsonFile()
        {
            
            if (File.Exists(jsonFileName))
            {
                using (StreamReader reader = new StreamReader(jsonFileName))
                {
                    string json = reader.ReadToEnd();
                    Dictionary<DayOfWeek, string> dictionaryFromJson = JsonConvert.DeserializeObject<Dictionary<DayOfWeek, string>>(json);
                    foreach (var item in dictionaryFromJson)
                    {
                        if (item.Value != Constant.ZERO_PERCENTAGE)
                        {
                            dayDiscountKeyValuePairs.Add(item.Key, int.Parse(item.Value.Replace(Constant.PERCENTAGE.ToString(), Constant.BLANK)));
                        }
                    }
                }
            }
            else
            {
                Console.WriteLine("File {0} does not exists. Loading preconfigured data", jsonFileName);
                LoadDaywiseDiscount();
            }
        }

        private static void LoadDaywiseDiscount()
        {
            dayDiscountKeyValuePairs.Add(DayOfWeek.Monday, 10);
            dayDiscountKeyValuePairs.Add(DayOfWeek.Wednesday, 5);
        }

        public override double CalculateDiscount()
        {
            int extraDiscountPercentage;
            DayOfWeek today = DateTime.Today.DayOfWeek;
            string configuredDay = ConfigurationSettings.AppSettings[Constant.OVERRIDEDAYVALUE];
            if (!string.IsNullOrWhiteSpace(configuredDay))
            {
                DayOfWeek tempToday;
                bool isValid = Enum.TryParse<DayOfWeek>(configuredDay, out tempToday);
                today = isValid ? tempToday : today;
            }
            bool hasValue = dayDiscountKeyValuePairs.TryGetValue(today, out extraDiscountPercentage);
            if (hasValue)
            {
                InitialPrice = InitialPrice * (100 - extraDiscountPercentage) / 100;
                Console.WriteLine("After {0}% weekday special discount for {1}, Final bill amount is: {2} \n", extraDiscountPercentage.ToString(), today, InitialPrice.ToString());
            }

            if (successor != null)
            {
                successor.InitialPrice = InitialPrice;
                successor.CalculateDiscount();
            }

            return InitialPrice;
        }
    }
}
