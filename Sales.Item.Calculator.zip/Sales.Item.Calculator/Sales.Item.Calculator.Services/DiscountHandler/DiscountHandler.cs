﻿namespace Sales.Item.Calculator.Services
{
    public abstract class DiscountHandler
    {
        protected DiscountHandler successor;
        public double InitialPrice { get; set; }
        public void SetSuccessor(DiscountHandler _successor)
        {
            this.successor = _successor;
        }
        public abstract double CalculateDiscount();
    }
}
