﻿using System;

namespace Sales.Item.Calculator.Services
{
    public class CreditCardDiscountHandler : DiscountHandler
    {
        public override double CalculateDiscount()
        {
            //Add credit card logic here
            throw new NotImplementedException();
        }
    }
}
