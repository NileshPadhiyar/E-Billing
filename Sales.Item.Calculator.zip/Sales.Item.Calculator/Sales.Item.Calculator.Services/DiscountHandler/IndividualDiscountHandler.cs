﻿using System;
using System.Linq;

namespace Sales.Item.Calculator.Services
{
    public class IndividualDiscountHandler : DiscountHandler
    {
        public override double CalculateDiscount()
        {
            Shopping shopping = Shopping.GetInstance();

            #region Apply Discount
            Console.WriteLine("\nPurchased Item List:");
            foreach (var item in shopping.cartItemList)
            {
                //based on item's creator - Apply Discount
                item.PriceWithDiscount = item.DiscountItemCreator.ApplyDiscount(item.Item.Price, item.Quantity);
                string discountDetails = item.DiscountItemCreator.GetDiscountDetails();
                Console.WriteLine("Item: {0} \t | Item Price: {1} \t| {2} | Quantity: {3} | Price after Discount: {4}", item.Item.ItemName.Trim(), item.Item.Price, discountDetails, item.Quantity, item.PriceWithDiscount);
            }
            #endregion

            #region Get Total with discount

            double billAmount = shopping.cartItemList.Sum(m => m.PriceWithDiscount);
            int totalQuantity = shopping.cartItemList.Sum(m => m.Quantity);
            Console.WriteLine("\nTotal => Quantity: {0} | Bill Amount: {1}", totalQuantity, billAmount);
            InitialPrice = billAmount;

            #endregion

            if (successor != null)
            {
                successor.InitialPrice = InitialPrice;
                successor.CalculateDiscount();
            }

            return InitialPrice;
        }
    }
}
