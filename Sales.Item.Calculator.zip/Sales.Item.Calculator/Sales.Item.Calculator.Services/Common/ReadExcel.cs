﻿using Microsoft.Office.Interop.Excel;
using Sales.Item.Calculator.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Sales.Item.Calculator.Services
{
    public class ReadExcel
    {
        public List<ItemModel> productList = new List<ItemModel>();
        private void LoadProductsFromExcel()
        {
            Application excel = new Application();
            Workbook workbook = excel.Workbooks.Open(System.AppContext.BaseDirectory + "../../ProductDetailsUpdated.xlsx");
            Worksheet worksheet = workbook.Sheets[1];
            Range range = worksheet.UsedRange;
            object temp2 = range.Value2;

            int rowCount = range.Rows.Count;
            int columnCount = range.Columns.Count;

            for (int i = 2; i <= rowCount; i++)
            {
                ItemModel row = new ItemModel();
                row.ItemId = i - 1;
                row.ItemName = range.Cells[i, 1].Value2;
                row.Price = range.Cells[i, 2].Value2;
                row.Discount = range.Cells[i, 3].Value2;

                //ProductList.Add(row);
            }
            //cleanup
            GC.Collect();
            GC.WaitForPendingFinalizers();

            //rule of thumb for releasing com objects:
            //  never use two dots, all COM objects must be referenced and released individually
            //  ex: [somthing].[something].[something] is bad

            //release com objects to fully kill excel process from running in the background
            Marshal.ReleaseComObject(range);
            Marshal.ReleaseComObject(worksheet);

            //close and release
            workbook.Close();
            Marshal.ReleaseComObject(workbook);

            //quit and release
            excel.Quit();
            Marshal.ReleaseComObject(excel);

        }
    }
}
