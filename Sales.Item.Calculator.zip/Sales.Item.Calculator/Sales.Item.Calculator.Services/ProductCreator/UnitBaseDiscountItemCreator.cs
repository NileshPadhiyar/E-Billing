﻿using Sales.Item.Calculator.Common;

namespace Sales.Item.Calculator.Services
{
    public class UnitBaseDiscountItemCreator: DiscountItem
    {
        private int _onBuyOfQuantityValue;
        private int _getFreeQuantityValue;

        public UnitBaseDiscountItemCreator(string discountDetails)
        {
            SetDiscountValue(discountDetails);
        }
        public override void SetDiscountValue(string discountDetails)
        {
            if (discountDetails.IndexOf(Constant.TILDE) > 0)
            {
                string[] unitValue = discountDetails.Split(Constant.TILDE);
                _onBuyOfQuantityValue = int.Parse(unitValue[0]);
                _getFreeQuantityValue = int.Parse(unitValue[1]);
            }
        }

        public override double ApplyDiscount(double price, int quantity)
        {
            return price * calculatePrice(quantity, _onBuyOfQuantityValue, _getFreeQuantityValue);
        }

        private double calculatePrice(int quantity, int onBuyOfQuantityValue, int getFreeQuantityValue)
        {
            int temp = 0;
            if ((onBuyOfQuantityValue + getFreeQuantityValue) > 0)
            {
                temp = quantity / (onBuyOfQuantityValue + getFreeQuantityValue);
            }
            return (quantity - temp);
        }

        public override string GetDiscountDetails()
        {
            return "Buy " + _onBuyOfQuantityValue + " Get " + _getFreeQuantityValue + " Free Discount";
        }
    }
}
