﻿using Sales.Item.Calculator.Common;

namespace Sales.Item.Calculator.Services
{
    public class PercentageDiscountItemCreator: DiscountItem
    {
        private int _percentageValue;

        public PercentageDiscountItemCreator(string discountDetails)
        {
            SetDiscountValue(discountDetails);
        }

        public override void SetDiscountValue(string discountDetails)
        {
            if (discountDetails.IndexOf(Constant.PERCENTAGE) > 0)
            {
                discountDetails = discountDetails.Replace(Constant.PERCENTAGE.ToString(), Constant.BLANK).ToString();                
            }
            int.TryParse(discountDetails, out _percentageValue);
        }

        public override double ApplyDiscount(double price, int quantity)
        {
            return price * quantity * ((double)(100 - _percentageValue) / 100);
        }

        public override string GetDiscountDetails()
        {
            return _percentageValue + "% Discount";
        }
    }
}
