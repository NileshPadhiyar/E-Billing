﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Sales.Item.Calculator.Services.Test.ProductCreator
{
    [TestClass]
    public class UnitBaseDiscountItemCreatorTest
    {
        [TestMethod]
        public void ApplyDiscount_Should_Return_Calculated_Value_ValidInput()
        {
            #region Prepare Data
            string percentage = "3~1";
            double price = 100;
            int quantity = 4;
            #endregion

            #region Actaul Method Call
            UnitBaseDiscountItemCreator creator = new UnitBaseDiscountItemCreator(percentage);
            double result = creator.ApplyDiscount(price, quantity);
            #endregion

            #region Assert
            Assert.AreEqual(300.00, result);
            #endregion
        }

        [TestMethod]
        public void ApplyDiscount_Should_Return_Calculated_Value_InvalidInput()
        {
            #region Prepare Data
            string percentage = "Xyz";
            double price = 100;
            int quantity = 4;
            #endregion

            #region Actaul Method Call
            UnitBaseDiscountItemCreator creator = new UnitBaseDiscountItemCreator(percentage);
            double result = creator.ApplyDiscount(price, quantity);
            #endregion

            #region Assert
            Assert.AreEqual(400, result);       //Should Return Amount without Discount
            #endregion
        }

        [TestMethod]
        public void CalculateDiscount_Should_Return_DiscountDetail_ValidInput()
        {
            #region Prepare Data
            string percentage = "3~1";
            #endregion

            #region Actaul Method Call
            UnitBaseDiscountItemCreator creator = new UnitBaseDiscountItemCreator(percentage);
            string discountDetails = creator.GetDiscountDetails();
            #endregion

            #region Assert
            Assert.AreEqual("Buy 3 Get 1 Free Discount", discountDetails);
            #endregion
        }

        [TestMethod]
        public void CalculateDiscount_Should_Return_DiscountDetail_InvalidWithoutSeparator()
        {
            #region Prepare Data
            string percentage = "31";
            #endregion

            #region Actaul Method Call
            UnitBaseDiscountItemCreator creator = new UnitBaseDiscountItemCreator(percentage);
            string discountDetails = creator.GetDiscountDetails();
            #endregion

            #region Assert
            Assert.AreEqual("Buy 0 Get 0 Free Discount", discountDetails);
            #endregion
        }

        [TestMethod]
        public void CalculateDiscount_Should_Return_DiscountDetail_InvalidWithNonNumeric()
        {
            #region Prepare Data
            string percentage = "Test";
            #endregion

            #region Actaul Method Call
            UnitBaseDiscountItemCreator creator = new UnitBaseDiscountItemCreator(percentage);
            string discountDetails = creator.GetDiscountDetails();
            #endregion

            #region Assert
            Assert.AreEqual("Buy 0 Get 0 Free Discount", discountDetails);
            #endregion
        }
    }
}
