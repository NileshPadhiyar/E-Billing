﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Sales.Item.Calculator.Services.Test.ProductCreator
{
    [TestClass]
    public class PercentageDiscountItemCreatorTest
    {
        [TestMethod]
        public void ApplyDiscount_Should_Return_Calculated_Value_ValidInput()
        {
            #region Prepare Data
            string percentage = "10%";
            double price = 100;
            int quantity = 5;
            #endregion

            #region Actaul Method Call
            PercentageDiscountItemCreator creator = new PercentageDiscountItemCreator(percentage);
            double result = creator.ApplyDiscount(price, quantity);
            #endregion

            #region Assert
            Assert.AreEqual(450.00, result);
            #endregion
        }

        [TestMethod]
        public void ApplyDiscount_Should_Return_Calculated_Value_InvalidInput()
        {
            #region Prepare Data
            string percentage = "test%";
            double price = 100;
            int quantity = 5;
            #endregion

            #region Actaul Method Call
            PercentageDiscountItemCreator creator = new PercentageDiscountItemCreator(percentage);
            double result = creator.ApplyDiscount(price, quantity);
            #endregion

            #region Assert
            Assert.AreEqual(500.00, result);       //Should Return Amount without Discount
            #endregion
        }

        [TestMethod]
        public void CalculateDiscount_Should_Return_DiscountDetail_ValidInput()
        {
            #region Prepare Data
            string percentage = "10%";
            #endregion

            #region Actaul Method Call
            PercentageDiscountItemCreator creator = new PercentageDiscountItemCreator(percentage);
            string discountDetails = creator.GetDiscountDetails();
            #endregion

            #region Assert
            Assert.AreEqual("10% Discount", discountDetails);
            #endregion
        }

        [TestMethod]
        public void CalculateDiscount_Should_Return_DiscountDetail_OnlyIntAsInput()
        {
            #region Prepare Data
            string percentage = "10";
            #endregion

            #region Actaul Method Call
            PercentageDiscountItemCreator creator = new PercentageDiscountItemCreator(percentage);
            string discountDetails = creator.GetDiscountDetails();
            #endregion

            #region Assert
            Assert.AreEqual("10% Discount", discountDetails);
            #endregion
        }

        [TestMethod]
        //[ExpectedException(typeof(Exception))]
        public void CalculateDiscount_Should_Return_DiscountDetail_InvalidInput()
        {
            #region Prepare Data
            string percentage = "Test%";
            #endregion

            #region Actaul Method Call
            PercentageDiscountItemCreator creator = new PercentageDiscountItemCreator(percentage);
            string discountDetails = creator.GetDiscountDetails();
            #endregion

            #region Assert
            Assert.AreEqual("0% Discount", discountDetails);
            #endregion
        }
    }
}
