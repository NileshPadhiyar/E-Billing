﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Sales.Item.Calculator.Services.Test.Common;

namespace Sales.Item.Calculator.Services.Test.DiscountHandler
{
    [TestClass]
    public class WeekdayDiscountHandlerTest
    {
        [TestMethod]
        public void CalculateDiscount_Should_Calculate_WeekdayDiscount()
        {
            #region Create/Load Data
            DataProcessor dataProcessor = new DataProcessor();
            #endregion

            #region Actaul Method Call
            WeekdayDiscountHandler handler = new WeekdayDiscountHandler();
            handler.InitialPrice = 1000;
            double result = handler.CalculateDiscount();
            #endregion

            #region Assert
            Assert.AreEqual(dataProcessor.getPercentage(1000), result);
            #endregion
        }
    }
}
