﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Sales.Item.Calculator.Services.Test.Common;
using System;
using System.Collections.Generic;

namespace Sales.Item.Calculator.Services.Test.DiscountHandler
{
    [TestClass]
    public class IndividualDiscountHandlerTest
    {
        Shopping shopping = Shopping.GetInstance();

        [TestMethod]
        public void CalculateDiscount_Should_Calculate_IndividualDiscount()
        {
            #region Create/Load Data
            DataProcessor dataProcessor = new DataProcessor();
            List<Tuple<int, string, double, string, int>> productList = dataProcessor.GetDefaultProductList();

            foreach (var product in productList)
            {
                shopping.AddItemToCartWithCreatorType(dataProcessor.GetProduct(product.Item1, product.Item2, product.Item3, product.Item4), product.Item5);
            }
            #endregion

            #region Actaul Method Call
            IndividualDiscountHandler handler = new IndividualDiscountHandler();
            double result = handler.CalculateDiscount();
            #endregion

            #region Assert
            double expectedResult = dataProcessor.CalculatePrice(productList);
            Assert.AreEqual(expectedResult, result);
            #endregion
        }
    }
}
