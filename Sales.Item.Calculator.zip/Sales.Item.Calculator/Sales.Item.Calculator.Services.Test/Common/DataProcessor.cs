﻿using Sales.Item.Calculator.Common;
using Sales.Item.Calculator.Models;
using System;
using System.Collections.Generic;

namespace Sales.Item.Calculator.Services.Test.Common
{
    public class DataProcessor
    {
        public ItemModel GetProduct(int id, string itemName, double price, object discount)
        {
            return new ItemModel() { ItemId = id, ItemName = itemName, Price = price, Discount = discount };
        }

        public List<Tuple<int, string, double, string, int>> GetDefaultProductList()
        {
            List<Tuple<int, string, double, string, int>> productList = new List<Tuple<int, string, double, string, int>>();
            productList.Add(new Tuple<int, string, double, string, int>(1, "Product 1", 100, "0%", 10));
            productList.Add(new Tuple<int, string, double, string, int>(2, "Product 2", 100, "5%", 1));
            productList.Add(new Tuple<int, string, double, string, int>(3, "Product 3", 100, "3~1", 4));
            productList.Add(new Tuple<int, string, double, string, int>(4, "Product 4", 100, "10%", 15));
            productList.Add(new Tuple<int, string, double, string, int>(5, "Product 5", 100, "0%", 1));
            return productList;
        }

        public double CalculatePrice(List<Tuple<int, string, double, string, int>> productList)
        {
            double totalAmount = 0;
            string[] unitValue;
            foreach (var product in productList)
            {
                if (product.Item4.Contains(Constant.PERCENTAGE.ToString()))
                {
                    totalAmount = totalAmount + (product.Item3 * product.Item5 * ((double)(100 - int.Parse(product.Item4.Replace("%", ""))) / 100));
                }
                else if (product.Item4.Contains(Constant.TILDE.ToString()))
                {
                    unitValue = product.Item4.Split(Constant.TILDE);
                    totalAmount = totalAmount + (product.Item3 * (product.Item5 - (product.Item5/(int.Parse(unitValue[0]) + int.Parse(unitValue[1])))));
                }

            }
            return totalAmount;
        }

        public int getPercentage(double price)
        {
            int percentage = 0;            
            switch (DateTime.Today.DayOfWeek)
            {
                case DayOfWeek.Sunday:
                case DayOfWeek.Tuesday:
                case DayOfWeek.Thursday:
                case DayOfWeek.Friday:
                case DayOfWeek.Saturday:
                    percentage = 0;
                    break;
                case DayOfWeek.Monday:
                    percentage = 10;
                    break;
                case DayOfWeek.Wednesday:
                    percentage = 5;
                    break;
                default:
                    break;
            }
            return 1000 * (100 - percentage) / 100;
        }

    }
}
