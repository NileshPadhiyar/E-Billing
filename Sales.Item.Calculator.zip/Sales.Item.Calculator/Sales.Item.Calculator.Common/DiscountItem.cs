﻿namespace Sales.Item.Calculator.Common
{
    public abstract class DiscountItem
    {
        public abstract void SetDiscountValue(string discountDetails);
        public abstract double ApplyDiscount(double price, int pu);
        public abstract string GetDiscountDetails();
    }
}
