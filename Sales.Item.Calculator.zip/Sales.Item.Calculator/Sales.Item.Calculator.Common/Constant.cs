﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sales.Item.Calculator.Common
{
    public static class Constant
    {
        public const char PERCENTAGE = '%';
        public const char TILDE = '~';
        public const string BLANK = "";
        public const string ZERO_PERCENTAGE = "%";
        public const string OVERRIDEDAYVALUE = "OverrideDayValue";
        public const string NO = "N";
    }
}
