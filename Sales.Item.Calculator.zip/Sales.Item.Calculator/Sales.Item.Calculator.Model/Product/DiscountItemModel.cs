﻿using Sales.Item.Calculator.Common;

namespace Sales.Item.Calculator.Models
{
    public class DiscountItemModel
    {
        public ItemModel Item { get; set; }
        public int Quantity { get; set; }
        public DiscountItem DiscountItemCreator { get; set; }
        public double PriceWithDiscount { get; set; }
    }
}
